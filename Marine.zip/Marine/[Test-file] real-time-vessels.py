#!/usr/bin/env python3
"""
🌊 MARINE WATCH - Real-Time Ocean Monitoring System
Live Environmental Tracking | Vessel Monitoring | Dynamic Alerting
"""

import streamlit as st
import numpy as np
import pandas as pd
import folium
from streamlit_folium import st_folium
from folium.plugins import TimestampedGeoJson, MeasureControl, HeatMap
import math
from datetime import datetime, timedelta
import time
import threading
from scipy.interpolate import griddata  # you can use this for smoothing/gridding later

# Configuration
st.set_page_config(layout="wide", page_title="Marine Watch")
st.title("🌍 Real-Time Marine Monitoring System")

class MarineWatch:
    def __init__(self):
        # Arabian Gulf bounding box
        self.sea_bounds = {
            'north': 28.5, 'south': 24.0,
            'west': 48.5, 'east': 54.0
        }

        # Initialize session state once
        if 'data' not in st.session_state:
            st.session_state.data = self._init_marine_data()
            st.session_state.vessels = self._init_vessels()
            st.session_state.incidents = []
            st.session_state.last_update = datetime.now()

        # Build the base map and state
        self.map = self._create_base_map()
        self.marker_pos = [26.2235, 50.5826]
        self.update_thread = None
        


    def _init_marine_data(self):
        """Initialize a regular lat/lon grid with environmental fields."""
        nx, ny = 100, 100
        lon_lin = np.linspace(self.sea_bounds['west'], self.sea_bounds['east'], nx)
        lat_lin = np.linspace(self.sea_bounds['south'], self.sea_bounds['north'], ny)
        xx, yy = np.meshgrid(lon_lin, lat_lin)
        pts = xx.size

        return pd.DataFrame({
            'lon': xx.ravel(),
            'lat': yy.ravel(),
            'depth': self._calculate_depth(yy.ravel()),
            'temp': 28 + np.random.normal(0, 2, pts),
            'salinity': 37.5 + np.random.normal(0, 0.5, pts),
            'current_speed': np.random.uniform(0, 2, pts),
            'current_dir': np.random.uniform(0, 360, pts)
        })
        time.sleep(3000)

    def _calculate_depth(self, lat_array):
        """Make a simple depth gradient deeper to the south."""
        return np.abs(50 * (lat_array - 25.5) + np.random.normal(0, 10, len(lat_array)))

    def _init_vessels(self):
        """Spawn a fleet of vessels with random starts & destinations."""
        return [self._create_vessel() for _ in range(25)]

    def _create_vessel(self):
        types = ['Cargo', 'Tanker', 'Fishing', 'Passenger', 'Patrol']
        return {
            'id': np.random.randint(1000, 9999),
            'type': np.random.choice(types),
            'speed': np.random.uniform(5, 25),          # knots
            'course': np.random.uniform(0, 360),       # degrees
            'position': [
                np.random.uniform(24.5, 28.0),
                np.random.uniform(49.0, 53.0)
            ],
            'last_update': datetime.now(),
            'destination': self._random_destination()
        }

    def _random_destination(self):
        """Pick a port as the vessel's goal."""
        ports = {
            'Doha': (25.2867, 51.5333),
            'Dammam': (26.4344, 50.1035),
            'Dubai': (25.2769, 55.2962),
            'Kuwait': (29.3759, 47.9774)
        }
        return ports[np.random.choice(list(ports.keys()))]

    def _create_base_map(self):
        """Set up the folium map, measurement tool, heatmap + vector field."""
        m = folium.Map(location=[26.0, 51.0], zoom_start=7)
        MeasureControl(position='bottomleft').add_to(m)
        self._add_heatmap_layer(m, 'temp', 'Temperature (°C)')
        self._add_heatmap_layer(m, 'salinity', 'Salinity (PSU)')
        self._add_vector_field(m)
        return m

    def _add_heatmap_layer(self, map_obj, field, label):
        HeatMap(
            data=st.session_state.data[['lat', 'lon', field]].values,
            name=label,
            gradient={0.4:'blue', 0.65:'lime', 1:'red'},
            radius=15, overlay=True
        ).add_to(map_obj)

    def _add_vector_field(self, map_obj):
        features = []
        sample = st.session_state.data.sample(100)
        now_iso = datetime.now().isoformat()
        for _, row in sample.iterrows():
            start = [row['lon'], row['lat']]
            end = [
                row['lon'] + 0.1 * math.cos(math.radians(row['current_dir'])),
                row['lat'] + 0.1 * math.sin(math.radians(row['current_dir']))
            ]
            features.append({
                'type':'Feature',
                'geometry':{'type':'LineString','coordinates':[start,end]},
                'properties':{'speed':row['current_speed'],'time':now_iso}
            })
        TimestampedGeoJson({
            'type':'FeatureCollection','features':features
        }, period='PT1M', add_last_point=True).add_to(map_obj)

    def _update_vessels(self):
        now = datetime.now()
        dt = (now - st.session_state.last_update).total_seconds()
        for v in st.session_state.vessels:
            # move forward
            dist = v['speed'] * dt / 3600
            lon = v['position'][1] + dist * math.cos(math.radians(v['course']))
            lat = v['position'][0] + dist * math.sin(math.radians(v['course']))
            # steer toward destination
            dest_lon, dest_lat = v['destination']
            desired = math.degrees(math.atan2(dest_lat-lat, dest_lon-lon))
            v['course'] += (desired-v['course'])*0.1
            v['position'] = [lat, lon]
            v['last_update'] = now

    def _update_environment(self):
        now = datetime.now()
        # diurnal temp swing
        st.session_state.data['temp'] += 0.1 * math.sin(now.hour/24*2*math.pi)
        st.session_state.data['salinity'] += np.random.normal(0,0.05,len(st.session_state.data))
        tidal = 0.5 * math.sin(now.hour/12.5*math.pi)
        st.session_state.data['current_speed'] = np.clip(
            st.session_state.data['current_speed'] + tidal,
            0, 3
        )

    def _detect_incidents(self):
        if np.random.rand() < 0.05:
            st.session_state.incidents.append({
                'type': np.random.choice(['Oil','Chemical','Debris']),
                'position':[np.random.uniform(24.5,28.0), np.random.uniform(49.0,53.0)],
                'start_time': datetime.now(),
                'radius':0.1,
                'intensity': np.random.uniform(0.5,1.0)
            })
            

    def _update_incidents(self):
        now = datetime.now()
        remove = []
        for i, inc in enumerate(st.session_state.incidents):
            hours = (now - inc['start_time']).total_seconds()/3600
            inc['radius'] = 0.1 + 0.05*hours
            inc['intensity'] *= 0.95
            if inc['intensity'] < 0.1:
                remove.append(i)
        for i in reversed(remove):
            st.session_state.incidents.pop(i)
            

    def run_updates(self):
        while True:
            self._update_vessels()
            self._update_environment()
            self._detect_incidents()
            self._update_incidents()
            st.session_state.last_update = datetime.now()
            time.sleep(3000)

    def start_update_thread(self):
        if self.update_thread is None:
            self.update_thread = threading.Thread(target=self.run_updates, daemon=True)
            self.update_thread.start()

    def get_analysis(self, lat, lon):
        df = st.session_state.data
        sub = df[
            df.lat.between(lat-0.05, lat+0.05) &
            df.lon.between(lon-0.05, lon+0.05)
        ]
        if sub.empty:
            return None
        return {
            'depth': sub.depth.mean(),
            'temp': sub.temp.mean(),
            'salinity': sub.salinity.mean(),
            'current_speed': sub.current_speed.mean(),
            'current_dir': sub.current_dir.mean()
        }

    def get_nearby_vessels(self, lat, lon):
        near = []
        for v in st.session_state.vessels:
            d = math.hypot((v['position'][0]-lat)*111,
                           (v['position'][1]-lon)*111*math.cos(math.radians(lat)))
            if d < 20:
                near.append({
                    'id':v['id'],'type':v['type'],
                    'distance':d,'speed':v['speed'],'bearing':v['course']
                })
        return near


def main():
    mw = MarineWatch()
    mw.start_update_thread()

    col1, col2 = st.columns([3,1])
    with col1:

        st.header("Live Marine Environment Map")
        map_data = st_folium(mw.map, width=1000, height=700, key="main_map")
        if map_data and map_data.get('last_clicked'):
            mw.marker_pos = [
                map_data['last_clicked']['lat'],
                map_data['last_clicked']['lng']
            ]

    with col2:
        st.header("Live Analytics")
        analysis = mw.get_analysis(*mw.marker_pos)
        if analysis:
            cols = st.columns(2)
            cols[0].metric("Depth", f"{analysis['depth']:.1f} m")
            cols[1].metric("Temperature", f"{analysis['temp']:.1f}°C")
            cols[0].metric("Salinity", f"{analysis['salinity']:.1f} PSU")
            cols[1].metric("Current Speed", f"{analysis['current_speed']:.1f} m/s")
            st.markdown(f"**Current Direction:** {analysis['current_dir']:.0f}°")
            st.subheader("Nearby Vessels")
            vessels = mw.get_nearby_vessels(*mw.marker_pos)
            if vessels:
                for v in vessels:
                    st.warning(f"🚢 {v['type']} Vessel {v['id']} ({v['distance']:.1f} km)")
            else:
                st.success("No vessels in 20 km radius")

        st.markdown("---")
        st.write(f"Last update: {st.session_state.last_update.strftime('%H:%M:%S')}")
        if st.button("Force Refresh"):
            mw.run_updates()
    

if __name__ == "__main__":
    main()
